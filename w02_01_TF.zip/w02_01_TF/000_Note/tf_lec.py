"""
This tutorial will provide a brief overview of the core concepts and functionality of Tensorflow. 
This tutorial will cover the following:
CS294-112 Fall 2018 Tensorflow Tutorial
0. What is Tensorflow
1. How to input data
2. How to perform computations
3. How to create variables
4. How to train a neural network for a simple regression problem
5. Tips and tricks
"""
import tensorflow as tf
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.cm as cm
import matplotlib.patches as mpatches

def tf_reset():
    try:
        sess.close()
    except:
        pass
    tf.reset_default_graph()
    return tf.Session()

"""
0. What is Tensorflow

 Tensorflow is a framework to define a series of computations. You define inputs, 
what operations should be performed, and then Tensorflow will compute the outputs for you.
Below is a simple high-level example:
"""
#create the session you'll work in\\n\",\n",
# you can think of this as a \\\"blank piece of paper\\\" that you'll be writing math on\\n\",\n",
sess = tf_reset()
    
# define your inputs
a = tf.constant(1.0)
b = tf.constant(2.0)
# do some operations
c = a + b

# get the result
c_run = sess.run(c)
print('c = {0}'.format(c_run))
