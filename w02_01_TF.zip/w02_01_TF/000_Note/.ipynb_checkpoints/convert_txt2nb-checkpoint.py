import nbformat

nb = nbformat.read('./TF_lecture.txt', 
                   nbformat.current_nbformat)

nbformat.write(nb, './TF_lecture.ipynb', 
               nbformat.NO_CONVERT)