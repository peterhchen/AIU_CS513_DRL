import random # random.randint()
import time   # time.process_time()

## =============================
## Action
State = type ("State", (object,), {})   
# Create state base class: "State" is a string object
# print("state: ", State)

class LightOn (State):
    def Execute (self):
        print("  Light is ON")

class LightOff (State):
    def Execute (self):
        print("  Light is OFF")

## =============================
## Transistion
class Transition (object):
    def __init__ (self, toState):
        self.toState = toState

    def Execute (self):
        print("Transitioning...")

## =============================
## Finite State Machine
class SimpleFSM (object):
    def __init__(self, char):
        self.char = char
        self.states = {}       # We are going to store the transition state.
        self.transitions = {}
        self.curState = None   # Current State
        self.trans = None      # Transition Action 

    def SetState (self, stateName):
        # Function to look at the State Name in the dictionary.
        self.curState = self.states[stateName]   

    def Transition (self, transName):
        # Look for transtion name in the dictionary
        self.trans = self.transitions[transName]  

    def Execute(self):
        if (self.trans):
            self.trans.Execute()
            self.SetState(self.trans.toState)
            self.trans = None
        self.curState.Execute()

## =============================
## Character
class Char (object):
    def __init__(self):
        self.FSM = SimpleFSM(self)
        self.LightON = True

## =============================
## main program
if __name__ == "__main__":
    light = Char()  # Create character for light object
    
    light.FSM.states["On"] = LightOn()    # Craete Light On inside the state machine.
    light.FSM.states["Off"] = LightOff()  # Craete Light Off inside the state machine.
    light.FSM.transitions["toOn"] = Transition("On")
    light.FSM.transitions["toOff"] = Transition("Off")

    light.FSM.SetState("On")

    # 
    for i in range(20):  # Loop for 20 times.
        # startTime = time.clock() 
        #print ('i:', i)
        startTime = time.process_time()
        timeInterval = 1
        # while (startTime + timeInterval > time.clock()): # Inside 1 second
        while (startTime + timeInterval > time.process_time()): # Inside 1 second
            # print("startTime:", startTime, "ime.process_time():", time.process_time())
            pass
        rn = random.randint(0, 2)
        # print ('rn:', rn)
        if (rn): # Generate 0 and 1
            # print ('light.LightON:', light.LightON)
            if (light.LightON):
                #print ('   if (light.LightON):', light.LightON)
                light.FSM.Transition("toOff")
                light.LightON = False
            else:
                #print ('   else (light.LightON):', light.LightON)
                light.FSM.Transition("toOn")
                light.LightON = True
        light.FSM.Execute()

