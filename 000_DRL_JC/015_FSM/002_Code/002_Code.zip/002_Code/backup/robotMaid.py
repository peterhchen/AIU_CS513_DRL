# https://www.youtube.com/watch?v=E45v2dD3IQU&list=PL82YdDfxhWsC-3kdTKK2_mwbNdBfVvb_M&index=9
# robotMain.py
# States: CleanDishes, Vacuum, Sleep
# FSM
# Character: Robot Maid
# Main Code:
# WHy do we need Finite State Machine?
# I1. Ugly Cod: Huge amount of code.
# 2. Difficult to manage
# 3. Difficult to m=navigate
# FSM prevent these problem to go back.

import random # random.randint()
import time   # time.clock()

## =============================
## Transistions
class Transition (object):
    def __init__(self, toState):
        self.toState = toState
    
    def Execute (self):
        print ("Transitioning")

## =============================
## States

class State (object):
    def __init__ (self, FSM):  # Pass in Finite State Machine
        self.FSM = FSM
        self.timer = 0
        self.startTime = 0
    
    # We have three function instead of one before.
    def Enter (self):
        self.timer = random.randint(0, 5)
        self.startTome = int (time.process_time())
    
    def Execute (self):
        pass

    def Exit(self):
        pass

class CleanDishes (State): # Pass in State
    def __init__ (self, FSM):
        super(CleanDishes, self).__init__(FSM)
    
    def Enter(self):
        print("Preparing to clean dishes.")
        super(CleanDishes, self).Enter()

    def Execute (self):
        print("Cleaning dishes")
        if (self.startTime + self.timer <= time.process_time()):
            if not (random.randint (1, 3) % 2):
                self.FSM.ToTransition ("toVacuum")
            else:
                self.FSM.ToTransition ("toSleep")
    
    def Exit(self):
        print("Finshied clearning dishes.")

class Vacuum (State):
    def __init__(self, FSM):
        super(Vacuum, self).__init__(FSM)

    def Enter (self):
        print("Starting to Vacuum")
        super(Vacuum, self).Enter()
    
    def Execute (self):
        print("Vacuuming")
        if (self.startTime + self.timer <= time.process_time()):
            if not (random.randint(1, 3) % 2):
                self.FSM.ToTransition ("toSleep")
            else:
                self.FSM.ToTransition("toCleanDishes")
        
    def Exit(self):
        print("Finished Vacuuming")

class Sleep (State):
    def __init__(self, FSM):
        super(Sleep, self).__init__(FSM)
        self.seelpAmount = 0
        self.startTime = 0

    def Enter (self):
        print("Starting to Sleep")
        super(Sleep, self).Enter()
    
    def Execute (self):
        print("Sleeping")
        if (self.startTime + self.timer <= time.process_time()):
            if not (random.randint(1, 3) % 2):
                self.FSM.ToTransition ("toVacuum")
            else:
                self.FSM.ToTransition("toCleanDishes")
        
    def Exit(self):
        print("Waking up from Sleep")

## =============================
## Finite State Machine: Similar to previous one.
class FSM (object):
    def __init__(self, char):
        self.char = char       # "character" is not defined 
        self.states = {}       # We are going to store the transition state.
        self.transitions = {}
        self.curState = None   # Current State
        # We need need prevState for more complex problem.
        self.prevState = None  
        self.trans = None      # Transition Action 

    def AddTransition (self, transName, transition):
        self.transitions[transName] = transition

    def AddState (self, stateName, state):
        self.states[stateName] = state
    
    def SetState (self, stateName):
        self.prevState = self.curState
        self.curState = self.states [stateName]

    def ToTransition (self, toTrans):
        self.trans = self.transitions[toTrans]  

    def Execute(self):
        if (self.trans):
            self.curState.Exit()
            self.trans.Execute()
            self.SetState(self.trans.toState)
            self.curState.Enter()
            self.trans = None
        self.curState.Execute()

## =============================
## Character
#class Char (object):
#    def __init__(self):
#        self.FSM = SimpleFSM(self)
#        self.LightON = True

# Implementation
Char = type("Char", (object,), {"day": 0})

class RobotMaid ():
    def __init__(self):
        self.FSM = FSM (self)

        ## States
        self.FSM.AddState ("Sleep", Sleep(self.FSM))
        self.FSM.AddState("CleanDishes", CleanDishes(self.FSM))
        self.FSM.AddState ("Vacuum", Vacuum(self.FSM))

        ## Transitions
        self.FSM.AddTransition("toSleep", Transition("Sleep"))
        self.FSM.AddTransition("toVacuum", Transition("Vacuum"))
        self.FSM.AddTransition("toCleanDishes", Transition("CleanDishes"))

        self.FSM.SetState("Sleep")

    def Execute(self):
        self.FSM.Execute()
                               
## =============================
## main program
if __name__ == "__main__":
    r = RobotMaid()      # Create robotMain object
    for i in range(10):  # Loop for 20 times.
        # startTime = clock() 
        startTime = time.process_time()
        timeInterval = 1
        # while (startTime + timeInterval > time.clock()): # Inside 1 second
        while (startTime + timeInterval > time.process_time()): # Inside 1 second
            # print("startTime:", startTime, "ime.process_time():", time.process_time())
            pass
        r.Execute()
